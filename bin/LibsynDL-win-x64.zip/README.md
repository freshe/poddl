# LibsynDL 
--------
Download podcasts from Libsyn

https://www.fredrikblank.se/libsyndl.php
https://github.com/freshe/LibsynDL

How to use: 
LibsynDL http://url.to.rss /OutputPath